package com.karakoc.mezat.auction;

import org.springframework.data.jpa.repository.JpaRepository;


public interface AuctionRepository extends JpaRepository<Auction,String> {

}
