package com.karakoc.mezat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MezatApplicationTests {

	@Test
	void contextLoads() {
	}

	@Test
	void bismillah(){

	}

}
