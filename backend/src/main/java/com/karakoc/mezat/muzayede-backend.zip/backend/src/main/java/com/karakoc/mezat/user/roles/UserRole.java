package com.karakoc.mezat.user.roles;

public enum UserRole {
    ROLE_ADMIN,
    ROLE_USER
}
