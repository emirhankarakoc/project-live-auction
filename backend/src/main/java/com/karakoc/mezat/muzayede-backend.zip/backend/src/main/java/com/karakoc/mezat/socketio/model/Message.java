package com.karakoc.mezat.socketio.model;

import lombok.Data;

@Data
public class Message {
    private String message;
}
